# cghrMisc

Richard Wen <rrwen.dev@gmail.com>  

Miscellaneous R tools for CGHR wich includes code that do not fit into other CGHR packages.

## Acknowledgements

Thanks to Nathan Kim from University of Toronto Schools (UTS) for his help with writing unit tests for this package during his Summer 2019 internship.

## Install

1. Install [R](https://www.r-project.org/) and [RTools](https://cran.r-project.org/bin/windows/Rtools/)
2. Install the [RStudio](https://www.rstudio.com/products/rstudio/download/#download) code editor
3. Open an [R Console](https://support.rstudio.com/hc/en-us/articles/200404846-Working-in-the-Console) in RStudio
4. Install [devtools](https://cran.r-project.org/package=devtools)
5. Install the `cghrMisc` package with `install_github`

```R
install.packages("devtools")
Sys.setenv(GITHUB_PAT = "<TOKEN>")
devtools::install_github("cghr-toronto/Misc")
```

**Note:** Replace `<Token>` inside the quotations `"` with the current access token available [here](https://github.com/cghr-toronto/start-here#repository-access-token)
