library(testthat)
library(cghrMisc)

test_check("cghrMisc")
