#' Tests for collapseNumbers function
#'
#' Arguments tested: x, separators, digits
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (collapseNumbers_test_default) Check that default example works
test_that("collapseNumbers() default behaviour works", {
  actual <- cghrMisc::collapseNumbers(c(14, 12, 15, 13, 3, 2, 1, 4, 5, 7))
  expected <- c("1-5", "7", "12-15")
  expect_equal(actual, expected)
})

# (collapseNumbers_test_digits) Check that leading zeroes work
test_that("collapseNumbers() fills in zeroes for consistent digit lengths", {
  actual <- cghrMisc::collapseNumbers(c(18, 7, 15, 10, 20, 11, 9, 19, 17, 16, 3, 1, 6, 2, 13), digits = 2)
  expected <- c("01-03", "06-07", "09-11", "13", "15-20")
  expect_equal(actual, expected)
})

# (collapseNumbers_test_separators) Check that different separators and digits work
test_that("collapseNumbers() works with different separators", {
  actual <- cghrMisc::collapseNumbers(c(2, 4, 3, 9, 10, 11, 14, 13), separator = "&", digits = 4)
  expected <- c("0002&0004", "0009&0011", "0013&0014")
  expect_equal(actual, expected)
})

# (collapseNumbers_test_duplicates) Ensure that duplicates are not deleted
test_that("collapseNumbers() handles duplicates", {
  actual <- cghrMisc::collapseNumbers(c(2, 2, 3, 4, 5, 7, 6))
  expected <- c("2-7")
  expect_equal(actual, expected)
})
