#' Tests for fillNA Function
#'
#' Arguments tested: x
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (fillNA_test_numbers) Check that numbers are filled
test_that("fillNA() fills numbers", {
  actual <- cghrMisc::fillNA(c(1, NA, NA, 2, NA))
  expected <- c(1, 1, 1, 2, 2)
  expect_equal(actual, expected)
})

# (fillNA_test_char) Check that characters are filled
test_that("fillNA() fills characters", {
  actual <- cghrMisc::fillNA(c("a", "B", NA, "cd", NA))
  expected <- c("a", "B", "B", "cd", "cd")
  expect_equal(actual, expected)
})

# (fillNA_test_NA) Check that NA is not filled, but anything else is filled otherwise
test_that("fillNA() does not fill if NA, but fills the rest otherwise", {
  actual <- cghrMisc::fillNA(c(NA, NA, NA, "a", NA, "1", NA))
  expected <- c(NA, NA, NA, "a", "a", "1", "1")
  expect_equal(actual, expected)
})
