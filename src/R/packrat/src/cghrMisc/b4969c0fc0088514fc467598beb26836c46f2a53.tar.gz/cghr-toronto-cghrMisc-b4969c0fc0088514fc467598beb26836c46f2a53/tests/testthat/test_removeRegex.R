#' Tests for removeRegex Function
#'
#' Arguments tested: dataframe, operator, count, each
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

test_that("removeRegex() default behaviour works", {
    expect_equal(cghrMisc::removeRegex("one ONE,-! 012345", replace=".", spaces=TRUE, numbers=TRUE),
        "one.ONE,-!.......")
})

test_that("removeRegex() equal to keepRegex(invert=TRUE)", {
    expect_equal(cghrMisc::removeRegex("one ONE,-! 012345", replace=".", spaces=FALSE, letters=FALSE,
        punctuation=TRUE, numbers=TRUE),
        cghrMisc::keepRegex("one ONE,-! 012345", replace=".", spaces=FALSE, letters=FALSE,
        punctuation=TRUE, numbers=TRUE, invert=TRUE))
})

test_that("removeRegex() can remove custom patterns", {
    expect_equal(cghrMisc::removeRegex("one ONE,-! 012345",
        other="!#$%&'()*+,.\\/:;<=>?@[\\\\^_`\\{|\\}~"),
        "one ONE- 012345")
})
