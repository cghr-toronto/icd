#' Tests for keepExist Function
#'
#' Arguments tested: dataframe, operator, count, each
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (keepExist_test_default) Check that default example works
test_that("keepExist() default behaviour works", {

  # (keepExist_test_default_data) Clean sample data with mtcars
  sample <- mtcars
  sampleValue <- sample[1, 2]

  # (keepExist_test_default_11nonna) Only keep complete rows where all values are non-NA
  sample[1,] <- NA
  isNARow <- rowSums(!is.na(sample)) == ncol(sample)
  actual <- nrow(cghrMisc::keepExist(sample, "==", ncol(sample)))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_default_atleastone) Keep if there is at least 1 non-NA value
  sample[1, 2] <- sampleValue
  isNARow <- rowSums(!is.na(sample)) >= 1
  actual <- nrow(cghrMisc::keepExist(sample, ">=", 1))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)

  #(keepExist_test_default_column) Only keep complete columns where values are only non-NA
  isNAColumn <- colSums(!is.na(sample)) == nrow(sample)
  actual <- ncol(cghrMisc::keepExist(sample, ">=", nrow(sample), each = "column"))
  expected <- length(isNAColumn[isNAColumn == TRUE])
  expect_equal(actual, expected)
})

# (keepExist_test_column_sample) Check that keepExists works column wise
test_that("keepExist() works column wise for sample mtcars data", {

  # (keepExist_test_column_sample_data) Clean sample data with mtcars
  sample <- mtcars
  sampleValue1 <- sample[2, 3]
  sampleValue2 <- sample[3, 5]
  sampleValue3 <- sample[5, 3]

  # (keepExist_test_column_sample_complete) All values must be non-NA
  sample[, 3] <- NA
  sample[, 5] <- NA
  isNAColumn <- colSums(!is.na(sample)) == nrow(sample)
  actual <- ncol(cghrMisc::keepExist(sample, "==", nrow(sample), each = "column"))
  expected <- length(isNAColumn[isNAColumn == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_column_sample_oneatleast) At least one non-NA value per column
  sample[2, 3] <- sampleValue1
  sample[3, 5] <- sampleValue2
  isNAColumn <- colSums(!is.na(sample)) >= 1
  actual <- ncol(cghrMisc::keepExist(sample, ">=", 1, each = "column"))
  expected <- length(isNAColumn[isNAColumn == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_column_sample_oneonly) At least 2 non-NA values per column
  sample[5, 3] <- sampleValue3
  isNAColumn <- colSums(!is.na(sample)) >= 2
  actual <- ncol(cghrMisc::keepExist(sample, ">=", 2, each = "column"))
  expected <- length(isNAColumn[isNAColumn == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_column_sample_notone) Number of non-NA values can't be one per column
  isNAColumn <- colSums(!is.na(sample)) != 1
  actual <- ncol(cghrMisc::keepExist(sample, "!=", 1, each = "column"))
  expected <- length(isNAColumn[isNAColumn == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_column_sample_allafter) All values must be non-NA after modifications
  isNAColumn <- colSums(!is.na(sample)) == nrow(sample)
  actual <- ncol(cghrMisc::keepExist(sample, "==", nrow(sample), each = "column"))
  expected <- length(isNAColumn[isNAColumn == TRUE])
  expect_equal(actual, expected)
})

# (keepExist_test_row_sample) Check that keepExists works row wise
test_that("keepExist() works row wise for sample mtcars data", {

  # (keepExist_test_row_sample_data) Clean sample data with mtcars
  sample <- mtcars
  sampleValue1 <- sample[3, 5]
  sampleValue2 <- sample[5, 1]
  sampleValue3 <- sample[5, 3]

  # (keepExist_test_row_sample_complete) All values must be non-NA
  sample[3, ] <- NA
  sample[5, ] <- NA
  isNARow <- rowSums(!is.na(sample)) == ncol(sample)
  actual <- nrow(cghrMisc::keepExist(sample, "==", ncol(sample), each = "row"))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_row_sample_oneatleast) At least one non-NA value per row
  sample[3, 5] <- sampleValue1
  sample[5, 1] <- sampleValue2
  isNARow <- rowSums(!is.na(sample)) >= 1
  actual <- nrow(cghrMisc::keepExist(sample, ">=", 1, each = "row"))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_row_sample_oneonly) At least 2 non-NA values per row
  sample[5, 3] <- sampleValue3
  isNARow <- rowSums(!is.na(sample)) >= 2
  actual <- nrow(cghrMisc::keepExist(sample, ">=", 2, each = "row"))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_row_sample_notone) Number of non-NA values can't be one per row
  isNARow <- rowSums(!is.na(sample)) != 1
  actual <- nrow(cghrMisc::keepExist(sample, "!=", 1, each = "row"))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)

  # (keepExist_test_row_sample_allafter) All values must be non-NA after modifications
  isNARow <- rowSums(!is.na(sample)) == ncol(sample)
  actual <- nrow(cghrMisc::keepExist(sample, "==", ncol(sample), each = "row"))
  expected <- length(isNARow[isNARow == TRUE])
  expect_equal(actual, expected)
})

# (keepExist_test_error_operator) Check invalid operators
test_that("keepExist() rejects invalid operators", {
  expect_error(cghrMisc::keepExist(sample, operator = "g"), "Invalid operator.")
})

# (keepExist_test_error_each) Check invalid each argument
test_that("keepExist() rejects invalid 'each' param", {
  expect_error(cghrMisc::keepExist(sample, each = "g"), "Invalid")
})
