test_that("replaceText() equal to str_replace_all()", {
    expect_equal(replaceText("a b c", " ", " | "), stringr::str_replace_all("a b c", " ", " | "))
})

test_that("replaceText() otherwise works as intended", {
    expect_equal(replaceText("5@$(*Bq       BJr_8e!&ksj  AaDSm(%&7os", "(\\W|_)", "g"), "5ggggBqgggggggBJrg8eggksjggAaDSmggg7os")
})
