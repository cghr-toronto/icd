#' Tests for removeExtraSpaces Function
#'
#' Arguments tested: string
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

test_that("removeExtraSpaces() removes all extra whitespace", {
  expect_match(cghrMisc::removeExtraSpaces("       \na  \n b\n    c     \n      "), "(\\S+ )+\\S")
})
