#' Tests for keepRegex Function
#'
#' Arguments tested: dataframe, operator, count, each
#' \cr
#' Arguments not tested: invert
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (keepRegex_test_min) Check that minimal arguments work
test_that("minimal arguments work", {
  expect_match(cghrMisc::keepRegex("!@#$* (&!-++=) abcdeQ fgNhij Oklm11nopqGrstDu vwxyz 012345"), "")
})

# (keepRegex_test_letter) Check that letters are kept
test_that("keepRegex() keeps letters", {
  expect_match(cghrMisc::keepRegex("abcdeQfgNhijOklmnopqGr11stDuvwxyz 012345", letters=TRUE), "[a-zA-Z]+")
})

# (keepRegex_test_number) Check that numbers are kept
test_that("keepRegex() keeps numbers", {
  expect_match(cghrMisc::keepRegex("abcdeQfgNhijOklmn11opqGrstDuvwxyz 012345", numbers=TRUE), "[0-9]+")
})

# (keepRegex_test_punc) Check that punctuation is kept
test_that("keepRegex() keeps punctuation", {
  expect_match(cghrMisc::keepRegex("!@#$*(&!-++=) abcdeQfgNhijOklm11nopqGrstDuvwxyz 012345", punctuation=TRUE), "[^a-zA-z0-9]|_+")
})

# (keepRegex_test_space) Check that spaces are removed
test_that("keepRegex() doesn't keep spaces", {
  expect_match(cghrMisc::keepRegex("!@#$* (&!-++=) abcdeQ fgNhij Oklm11nopqGrstDu vwxyz 012345", spaces=FALSE, punctuation=TRUE, letters=TRUE, numbers=TRUE), "\\S+")
})

# (keepRegex_test_keep) Check that symbolsare kept correctly with other arguments
test_that("keepRegex() keeps", {
  expect_equal(cghrMisc::keepRegex("!@#$*(&!-++=) abcdeQfgNhijOklm11nopqGrstDuvwxyz 012345", "a-zA-z"), "abcdeQfgNhijOklmnopqGrstDuvwxyz")
  expect_equal(cghrMisc::keepRegex("!@#$*(&!-++=) abcdeQfgNhijOklm11nopqGrstDuvwxyz 012345", "0-9"), "11012345")
  expect_equal(cghrMisc::keepRegex("!@#$*(&!-++=) abcdeQfgNhijOklm11nopqGrstDuvwxyz 012345", "+"), "++")
})

# (keepRegex_test_replace) Test that symbols are replaced correctly with different arguments
test_that("keepRegex() replaces", {
  expect_equal(cghrMisc::keepRegex("one ONE,-! 012345", replace=".", spaces=FALSE, letters=FALSE, numbers=FALSE, punctuation=TRUE), ".......,-!.......")
  expect_equal(cghrMisc::keepRegex("one ONE,-! 012345", replace=".", spaces=TRUE, letters=TRUE, punctuation=FALSE, numbers=FALSE), "one ONE... ......")
  expect_equal(cghrMisc::keepRegex("one .ONE,-! 012345", replace=".", spaces=TRUE, letters=FALSE, punctuation=TRUE, numbers=FALSE), "... ....,-! ......")
})
