
#' Collapse a Range of Numbers into Short Form
#'
#' Function for collapsing a range of numbers into short form.
#'
#' @param x (int) vector of numbers to collapse
#' @param separator (char) [default = "-"] symbol to use as a separator for each range
#' @param digits (int) [default = 0] integer value representing the number of leading zeroes
#'
#' @return (char) returns vector of characters with collapsed number ranges
#' @export
#'
#' @family number functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#' @seealso \href{https://stackoverflow.com/questions/16911773/collapse-runs-of-consecutive-numbers-to-ranges}{StackOverflow answer from sebastian-c}
#'
#' @examples
#' # c("1-5", "7", "12-15")
#' cghrMisc::collapseNumbers(c(14,12,15,13,3,2,1,4,5,7))
#'
#' # c("001-005", "007", "012-015")
#' cghrMisc::collapseNumbers(c(14,12,15,13,3,2,1,4,5,7), digits = 3)
#'
collapseNumbers <- function(x, separator = "-", digits = 0){

  # (collapseNumbers_increments) Sort and calculate increments
  x <- sort(unique(x))
  xdiff <- c(1, diff(x))
  xsplit <- split(x, cumsum(xdiff != 1))

  # (collapseNumbers_range) Collapse numbers to create ranges
  ranges <- lapply(xsplit, function(x){

    # (collapseNumbers_range_single) Format digits and return single value without a range
    if(length(x) %in% 1) {
      x <- sprintf(paste0("%0", digits, "d"), as.numeric(x))
      return(as.character(x))
    } else {

      # (collapseNumbers_range_format) Format digits and range with separator
      x[1] <- sprintf(paste0("%0", digits, "d"), as.numeric(x[1]))
      x[length(x)] <- sprintf(paste0("%0", digits, "d"), as.numeric(x[length(x)]))
      return(paste0(x[1], separator, x[length(x)]))
    }
  })

  # (collapseNumbers_return) Return collapsed ranges
  out <- unlist(ranges, use.names=FALSE)
  return(out)
}
