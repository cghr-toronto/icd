
#' Keep Text with Certain Patterns
#'
#' Function to conveniently keep only certain character symbols in text. Does not keep any text by default.
#'
#' @param x (character) character vector to keep certain symbols
#' @param other (character) [default = ""] other user defined symbols to keep
#' @param replace (character) [default = ""] the symbol used to replace symbols that are removed
#' @param letters [default = FALSE] set to TRUE to keep letters and FALSE to remove them
#' @param numbers [default = FALSE] set to TRUE to keep numbers and FALSE to remove them
#' @param punctuation [default = FALSE] set to TRUE to keep punctuation and FALSE to remove them
#' @param spaces [default = TRUE] set to TRUE keep spaces and FALSE to remove them
#' @param invert [default = FALSE] invert the behaviour, removing symbols instead of keeping them
#'
#' @return (character) returns a character vector of only the kept symbols
#' @export
#'
#' @family regex functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' sample <- c("one ONE,-! 012345")
#'
#' # Keep letters only
#' cghrMisc::keepRegex(sample, letters = TRUE)
#'
#' # Keep numbers only
#' cghrMisc::keepRegex(sample, numbers = TRUE)
#'
#' # Keep letters and punctuation only
#' cghrMisc::keepRegex(sample, letters = TRUE, punctuation = TRUE)
#'
#' # Keep letters and numbers only
#' cghrMisc::keepRegex(sample, letters = TRUE, numbers = TRUE)
#'
#' # Keep particular symbols
#' cghrMisc::keepRegex(sample, ",;")
#'
#  # Keep particular symbols, but replace with spaces
#' cghrMisc::keepRegex(sample, ",;", replace = " ")
#'
#' # Keep letters, numbers, and particular symbols
#' cghrMisc::keepRegex(sample, ",;", letters = TRUE, numbers = TRUE)
#'
#' # Do not keep spaces
#' cghrMisc::keepRegex(sample, letters = TRUE, spaces = FALSE)
#'
keepRegex <- function(x, other = "", replace = "", letters = FALSE, numbers = FALSE, punctuation = FALSE, spaces = FALSE, invert = FALSE) {

  # (keepRegex_available) Available patterns of symbols to keep based on arguments
  pattern <- ""
  if (letters) {
    pattern <- paste0(pattern, "a-zA-Z")
  }
  if (numbers) {
    pattern <- paste0(pattern, "0-9")
  }
  if (punctuation) {
    pattern <- paste0(pattern, "[:punct:]")
  }
  if (spaces) {
    pattern <- paste0(pattern, "[:space:]")
  }

  # (keepRegex_other) Other user provided symbols to keep
  pattern <- paste0(pattern, other)

  # (keepRegex_return) Return the character vector with only kept symbols
  if (pattern == "") {
    if (!invert) {
      pattern <- ".*"
    } else {
      return(x)
    }
  } else {
    if (!invert) {
      pattern <- paste0("[^", pattern, "]")
    } else {
      pattern <- paste0("[", pattern, "]")
    }
  }
  out <- gsub(pattern, replace, x)
  return(out)
}
