
#' Remove Extra White Spaces from a String
#'
#' Function that uses \code{\link[stringr:str_trim]{str_squish}} to remove any additional spaces inside of a string of text.
#'
#' @param string (char) the string of text to remove extra spaces from
#'
#' @return (char) the string of text with extra spaces removed
#' @export
#'
#' @family text functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' cghrMisc:::removeExtraSpaces(" a  b c   ") # "a b c"
#'
removeExtraSpaces <- function(string) {
  return(stringr::str_squish(string))
}
