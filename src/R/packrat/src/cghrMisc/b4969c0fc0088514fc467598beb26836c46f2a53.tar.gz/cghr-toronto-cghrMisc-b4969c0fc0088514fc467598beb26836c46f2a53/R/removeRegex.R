# Requires: keepRegex.R

#' Remove Text with Certain Patterns
#'
#' Function to conveniently remove certain character symbols in text. Does not remove any text by default.
#'
#' @param x (character) character vector to remove certain symbols
#' @param other (character) [default = ""] other user defined symbols to remove
#' @param replace (character) [default = ""] the symbol used to replace symbols that are removed
#' @param letters [default = FALSE] set to TRUE to remove letters and FALSE to keep them
#' @param numbers [default = FALSE] set to TRUE to remove numbers and FALSE to keep them
#' @param punctuation [default = FALSE] set to TRUE to remove punctuation and FALSE to keep them
#' @param spaces [default = FALSE] set to TRUE remove spaces and FALSE to keep them
#'
#' @return (character) returns a character vector with desired symbols removed
#' @export
#'
#' @family regex functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' sample <- c("one ONE,-! 012345")
#'
#' # Remove letters
#' cghrMisc::removeRegex(sample, letters = TRUE)
#'
#' # Remove numbers
#' cghrMisc::removeRegex(sample, numbers = TRUE)
#'
#' # Remove letters and punctuation
#' cghrMisc::removeRegex(sample, letters = TRUE, punctuation = TRUE)
#'
#' # Remove letters and numbers
#' cghrMisc::removeRegex(sample, letters = TRUE, numbers = TRUE)
#'
#' # Remove particular symbols
#' cghrMisc::removeRegex(sample, ",;")
#'
#  # Remove particular symbols, but replace with spaces
#' cghrMisc::removeRegex(sample, ",;", replace = " ")
#'
#' # Remove letters, numbers, and particular symbols
#' cghrMisc::removeRegex(sample, ",;", letters = TRUE, numbers = TRUE)
#'
#' # Remove spaces
#' cghrMisc::removeRegex(sample, spaces = FALSE)
#'
removeRegex <- function(x, other = "", replace = "", letters = FALSE, numbers = FALSE, punctuation = FALSE, spaces = FALSE) {
  out <- keepRegex(x, other = other, replace = replace, letters = letters, numbers = numbers, punctuation = punctuation, spaces = spaces, invert = TRUE)
  return(out)
}
