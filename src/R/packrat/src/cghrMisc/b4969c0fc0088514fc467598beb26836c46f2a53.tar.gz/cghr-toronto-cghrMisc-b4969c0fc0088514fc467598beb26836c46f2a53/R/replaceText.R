
#' Replace Text in a String
#'
#' Function that uses \code{\link[stringr:str_replace]{str_replace_all}} to replace particular text with other text defined by the user.
#'
#' @param string (char) the string to replace particular pattern of text from
#' @param pattern (char) a pattern of text or specific characters to replace
#' @param replacement (char) text to replace the defined text pattern from
#'
#' @return (char) the string of text with the pattern of text replaced with other text defined by the user
#' @export
#'
#' @family text functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' cghrMisc:::replaceText("a b c", " ", " | ") # "a || b || c"
#'
replaceText <- function(string, pattern, replacement) {
  return(stringr::str_replace_all(string, pattern, replacement))
}
