# Requires: removeExtraSpaces.R

#' Keep Only Rows or Columns with a Number of Non-NA Values
#'
#' Function to conveniently remove rows or columns with many NAs (assumed to be non-existing values).
#'
#' @param dataframe (dataframe) \code{\link{data.frame}} object with rows or columns to keep
#' @param operator (char) [default = ">"]
#' operator to consider rows for keeping:
#' \itemize{
#'   \item Equal to: "=="
#'   \item Not Equal to: "!="
#'   \item Less Than: "<"
#'   \item Less Than or Equal to: "<="
#'   \item Greater Than: ">"
#'   \item Greater Than or Equal to: ">="
#' }
#' @param count [default = 0] (int) the number of values for each row to consider from the operator
#' @param each (char) [default = "row"] checks each "row" or "column" to keep
#'
#' @return (dataframe) returns a \code{\link{data.frame}} object with only the rows or columns with a number of values (values that are non-NA) that are equal to, less than, or greater than the set count value
#' @export
#'
#' @family na functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' # Create samples to use
#' sample <- mtcars
#' sampleValue <- sample[1, 2]
#'
#' # Only keep complete rows where all values are non-NA
#' sample[1,] <- NA
#' cghrMisc::keepExist(sample, "==", nrow(sample))
#'
#' # Keep if there is at least 1 non-NA value
#' sample[1, 2] <- sampleValue
#' cghrMisc::keepExist(sample, ">=", 1)
#'
#' # Only keep complete columns where values are only non-NA
#' cghrMisc::keepExist(sample, ">=", nrow(sample), each = "column")
#'
keepExist <- function(dataframe, operator = ">", count = 0, each = "row") {

  # (keepExist_operator) Format operator
  operator <- tolower(removeExtraSpaces(operator))

  # (keepExist_each) 1 for rows and 2 for columns
  each <- tolower(removeExtraSpaces(each))
  if (each == 'column') {
    each <- 2
  } else if (each == 'row') {
    each <- 1
  } else {
    stop("Invalid argument for 'each': must be 'row' or 'column'")
  }

  # (keepExist_keep) Keep rows based on operator and count
  if (operator == "==") {
    keep <- apply(dataframe, each, function(r) sum(!is.na(r)) == count)
  } else if (operator == "!=") {
    keep <- apply(dataframe, each, function(r) sum(!is.na(r)) != count)
  } else if (operator == "<") {
    keep <- apply(dataframe, each, function(r) sum(!is.na(r)) < count)
  } else if (operator == "<=") {
    keep <- apply(dataframe, each, function(r) sum(!is.na(r)) <= count)
  } else if (operator == ">") {
    keep <- apply(dataframe, each, function(r) sum(!is.na(r)) > count)
  } else if (operator == ">=") {
    keep <- apply(dataframe, each, function(r) sum(!is.na(r)) >= count)
  } else {
    stop("Invalid operator.")
  }

  # (keepExist_return) Return the dataframe with only kept rows or columns
  if (each == 2) {
    out <- dataframe[, keep, drop = FALSE]
  } else {
    out <- dataframe[keep, ]
  }
  return(out)
}
