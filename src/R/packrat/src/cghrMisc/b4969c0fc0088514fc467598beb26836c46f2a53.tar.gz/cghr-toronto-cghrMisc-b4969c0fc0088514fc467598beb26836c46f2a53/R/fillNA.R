
#' Fill NA Values with Known Values
#'
#' Function for filling NA values with previously known values.
#'
#' @param x (vector) vector of values to fill
#'
#' @return (vector) returns vector of values with NAs filled with previously known values
#' @export
#'
#' @family na functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#' @seealso \href{https://stackoverflow.com/questions/10554741/fill-in-data-frame-with-values-from-rows-above}{StackOverflow answer from nacnudus}
#'
#' @examples
#' cghrMisc::fillNA(c(NA, 1, NA, NA, 2)) # c(NA, 1, 1, 1, 2)
#'
fillNA <- function(x) {
  notNA <- !is.na(x)
  out <- c(NA, x[which(notNA)])[cumsum(notNA)+1]
  return(out)
}
