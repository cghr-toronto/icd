#' Tests for collapseICD Function
#'
#' Arguments tested: wbd, separator, digits
#' \cr
#' Arguments not tested: leftPattern, ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (collapseWBD_test_default) Check that default example works
test_that("collapseWBD() default behaviour works", {
  actual <- cghrCodes::collapseWBD(c("1M05", "1m04", "1M03", "1B01", "1I01-1I03", "1I04"))
  expected <- c("1B01", "1I01-04", "1M03-05")
  expect_equal(actual, expected)
})

# (collapseWBD_test_digits) Check that different number of digits works with leading zeroes
test_that("collapseWBD() can use different digit lengths", {
  actual <- cghrCodes::collapseWBD(c("1M05", "1m04", "1M03", "1B021", "1I01-1I03", "1I04"), digits = 4)
  expected <- c("1B0021", "1I0001-0004", "1M0003-0005")
  expect_equal(actual, expected)
})

# (collapseWBD_test_separators) Check for different separators output
test_that("collapseWBD() can use different separators", {
  actual <- cghrCodes::collapseWBD(c("1M05", "1m04", "1M03", "1B01", "1I01-1I03", "1I04"), separator = "&")
  expected <- c("1B01", "1I01&04", "1M03&05")
  expect_equal(actual, expected)
})
