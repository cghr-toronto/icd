#' Tests for expandWBDNumbers Function
#'
#' Arguments tested: wbd
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (extractWBDNumbers_test_default) Check that example works
test_that("extractWBDNumbers() default behaviour works", {
  actual <- cghrCodes:::extractWBDNumbers(c("1M01", "1M02", "1B05", "1I03"))
  expected <- c("01", "02", "05", "03")
  expect_equal(actual, expected)
})

# (extractWBDNumbers_test_nonnum) Check that non numbers are removed after the left-hand side
test_that("extractWBDNumbers() removes non-numbers", {
  actual <- cghrCodes:::extractWBDNumbers(c("1MM9M2OIUMsd1", "OIW2UERE*#&U#o3seur+_)~"))
  expected <- c("921", "23")
  expect_equal(actual, expected)
})
