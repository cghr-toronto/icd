library(testthat)
library(cghrCodes)

test_check("cghrCodes")
