#' Tests for extractWBDLeft Function
#'
#' Arguments tested: wbd, leftPattern
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (extractWBDLeft_test_default) Check that default example works
test_that("extractWBDLeft() default behaviour works", {
  actual <- cghrCodes:::extractWBDLeft(c("1M01", "1M02", "1B05", "1I03"))
  expected <- c("1M", "1M", "1B", "1I")
  expect_equal(actual, expected)
})

# (extractWBDLeft_test_lower) Check that lowercase is accepted
test_that("extractWBDLeft() accepts lowercase letters", {
  actual <- cghrCodes:::extractWBDLeft(c("1m01", "1M02", "1B05", "1i03"))
  expected <- c("1m", "1M", "1B", "1i")
  expect_equal(actual, expected)
})
