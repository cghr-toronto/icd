#' Tests for expandICD10Data Function
#'
#' Arguments tested: dataframe, icd10Column, expandColumn
#' \cr
#' Arguments not tested: ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (expandICD10Data_data_sample1) Default example data
sample1 <- data.frame(
  codex = c("A", "A1", "C"),
  icd10 = c("AA5-AA7", "A10-A11", "C25 C28 C29-30"))

# (expandICD10Data_data_sample2) Sample data with different column names
sample2 <- data.frame(
  icd10 = c("AA5-AA7", "A10-A11", "C25 C28 C29-30"),
  codex = c("A", "A1", "C"))

# (expandICD10Data_data_sample3) Sample data with different icd10 column
sample3 <- data.frame(
  test = c("AA5-AA7", "A10-A11", "C25 C28 C29-30"),
  codex = c("A", "A1", "C"))

# (expandICD10Data_test_default) Check that default example works
test_that("expandICD10Data() default behaviour works", {
  actual <- cghrCodes::expandICD10Data(sample1)
  expected <- data.frame(
    codex = c("A1", "A1", "A", "A", "A", "C", "C", "C", "C"),
    icd10 = c("A10-A11", "A10-A11", "AA5-AA7", "AA5-AA7", "AA5-AA7", "C25 C28 C29-30", "C25 C28 C29-30", "C25 C28 C29-30", "C25 C28 C29-30"),
    icd10_expand = c("A10", "A11", "AA05", "AA06", "AA07", "C25", "C28", "C29", "C30"))
  expect_identical(actual, expected)
})

# (expandICD10Data_test_icd10Column_index) Check that different index can be used for icd10 column
test_that("expandICD10Data() can use custom index for icd10 range column", {
  actual <- cghrCodes::expandICD10Data(sample2, icd10Column = 1)$icd10_expand
  expected <- c("A10", "A11", "AA05", "AA06", "AA07", "C25", "C28", "C29", "C30")
  expect_setequal(actual, expected)
})

# (expandICD10Data_test_icd10Column_name) Check that different name can be used for icd10 column
test_that("expandICD10Data() can use custom name for icd10 range column", {
  actual <- cghrCodes::expandICD10Data(sample3, icd10Column = "test")$test_expand
  expected <- c("A10", "A11", "AA05", "AA06", "AA07", "C25", "C28", "C29", "C30")
  expect_setequal(actual, expected)
})

# (expandICD10Data_test_expandColumn) Check that differet name can be used for output expand column
test_that("expandICD10Data() can use custom name for expanded column", {
  actual <- cghrCodes::expandICD10Data(sample1, expandColumn = "test")$test
  expected <-  c("A10", "A11", "AA05", "AA06", "AA07", "C25", "C28", "C29", "C30")
  expect_setequal(actual, expected)
})
