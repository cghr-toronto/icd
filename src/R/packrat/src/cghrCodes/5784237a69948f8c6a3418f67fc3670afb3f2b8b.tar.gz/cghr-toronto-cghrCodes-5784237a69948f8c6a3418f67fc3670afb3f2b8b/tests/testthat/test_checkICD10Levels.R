#' Tests for checkICD10Levels Function
#'
#' Arguments tested: dataframe, higherICD10Column, lowerICD10Column, checkColumn
#' \cr
#' Arguments not tested: ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (test_checkICD10Levels_data1) Default sample data same as example
sample1 <- data.frame(
  icd10_high = c("AA5-AA10", "AA5-AA10", "C1-5"),
  icd10_low = c("AA5-AA7", "AA1-AA9", "C1 C2 C12"))

# (test_checkICD10Levels_data2) Sample data with extra columns in front
sample2 <- data.frame(
  a = c("1", "2", "3"),
  b = c("1", "2", "3"),
  icd10_low = c("AA5-AA7", "AA1-AA9", "C1 C2 C12"),
  icd10_high = c("AA5-AA10", "AA5-AA10", "C1-5"))

# (test_checkICD10Levels_data3) Sample data with different column names
sample3 <- data.frame(
  a = c("AA5-AA7", "AA1-AA9", "C1 C2 C12"),
  b = c("AA5-AA10", "AA5-AA10", "C1-5"))

# (test_checkICD10Levels_default) Check that default example works
test_that("checkICD10Levels() default behaviour works", {
  actual <- cghrCodes::checkICD10Levels(dataframe = sample1)$icd10_low_missed_in_icd10_high
  expected <- c("", "AA01 AA02 AA03 AA04", "C12")
  expect_equal(actual, expected)
})

# # (test_checkICD10Levels_col_index) Check that different column indices are accepted
test_that("checkICD10Levels() can take different low and high ICD10 column indices", {
  actual <- cghrCodes::checkICD10Levels(dataframe = sample2, higherICD10Column = 4, lowerICD10Column = 3)$icd10_low_missed_in_icd10_high
  expected <- c("", "AA01 AA02 AA03 AA04", "C12")
  expect_equal(actual, expected)
})

# (test_checkICD10Levels_col_names) Check that different column names are accepted
test_that("checkICD10Levels() can take different low and high ICD10 column names", {
  actual <- cghrCodes::checkICD10Levels(dataframe = sample3, higherICD10Column = 'b', lowerICD10Column = 'a')$a_missed_in_b
  expected <- c("", "AA01 AA02 AA03 AA04", "C12")
  expect_equal(actual, expected)
})

# (test_checkICD10Levels_col_check) Check that different check column names can be output
test_that("checkICD10Levels() can output a different check column name", {
  actual <- cghrCodes::checkICD10Levels(sample1, checkColumn = 'test')$test
  expected <- c("", "AA01 AA02 AA03 AA04", "C12")
  expect_equal(actual, expected)
})
