#' Tests for collapseICD10 Function
#'
#' Arguments tested: icd10, separators, digits
#' \cr
#' Arguments not tested: ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (test_checkICD10Levels_default) check that default example works
test_that("collapseICD10() default behaviour works", {
  actual <- cghrCodes::collapseICD10(c("AA5", "A4", "A3", "B55", "B10", "B56", "C10", "C100", "C101", "C102-C105"))
  expected <- c("A03-04", "AA05", "B10", "B55-56", "C10", "C100-105")
  expect_equal(actual, expected)
})

# (test_checkICD10Levels_separators) Check that "&" can be used as a separator
test_that("collapseICD10() can use different separators", {
  actual <- cghrCodes::collapseICD10(c("AA5", "A4", "A3", "B55", "B10", "B56", "C10", "C100", "C101", "C102-C105"), separator = "&")
  expected <- c("A03&04", "AA05", "B10", "B55&56", "C10", "C100&105")
  expect_equal(actual, expected)
})

# (test_checkICD10Levels_digits) Check that different digit lengths can be used
test_that("collapseICD10() can use different digit lengths", {
  actual <- cghrCodes::collapseICD10(c("AA5", "A0004", "A3", "B055", "B10", "B56", "C10", "C100", "C101", "C102-C105"), digits = 4)
  expected <- c("A0003-0004", "AA0005", "B0010", "B0055-0056", "C0010", "C0100-0105")
  expect_equal(actual, expected)
})

# (test_checkICD10Levels_bad_input) Check that bad input can be removed and that codes can still be collapsed
test_that("collapseICD10() handles bad input", {
  actual <- cghrCodes::collapseICD10(c("A$%A5", "A4", "A&%3", "B55", "B1)!0", "B56&(!*", "C10", "C!*&100", "C101", "C10!&$2-C105"), separator = "&")
  expected <- c("A03&04", "AA05", "B10", "B55&56", "C10", "C100&105")
  expect_equal(actual, expected)
})
