#' Tests for expandICD10Range Function
#'
#' Arguments tested: icd10Range, digits
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (expandICD10Range_test_default) Check that default example works
test_that("expandICD10Range() default behaviour works", {
  actual <- cghrCodes:::expandICD10Range("A1-5")
  expected <- c("A01", "A02", "A03", "A04", "A05")
  expect_equal(actual, expected)
})

# (expandICD10Range_test_digits) Check that different numbers can be used
test_that("expandICD10Range() works with different digit numbers", {
  actual <- cghrCodes:::expandICD10Range("A7-00013", digits = 4)
  expected <- c("A0007", "A0008", "A0009", "A0010", "A0011", "A0012", "A0013")
  expect_equal(actual, expected)
})

# (expandICD10Range_test_error_multirange) Check that only 1 range is accepted
test_that("expandICD10Range() errors out for more than one valid range", {
  expect_error(
    cghrCodes:::expandICD10Range("A1-5B1-5"),
    "Invalid range.")
})

# (expandICD10Range_test_error_diffletters) Check that ranges with different letters are rejected
test_that("expandICD10Range() errors out with ranges that have different start and end letters", {
  expect_error(
    cghrCodes:::expandICD10Range("A7-B00013", digits = 4),
    "Range .+ must use the same letter \\(suggestion: ")
})
