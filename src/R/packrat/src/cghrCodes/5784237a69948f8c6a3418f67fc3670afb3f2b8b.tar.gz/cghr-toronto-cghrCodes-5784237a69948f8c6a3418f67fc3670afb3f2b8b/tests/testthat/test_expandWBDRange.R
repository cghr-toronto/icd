#' Tests for expandWBDRange Function
#'
#' Arguments tested: wbdRange, digits
#' \cr
#' Arguments not tested: ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (expandWBDRange_test_default) Check that given example works
test_that("expandWBDRange() default behaviour works", {
  actual <- cghrCodes:::expandWBDRange("1M01-1M05")
  expected <- c("1M01", "1M02", "1M03", "1M04", "1M05")
  expect_equal(actual, expected)
})

# (expandWBDRange_test_lower) Check that lowercase is accepted
test_that("expandWBDRange() accepts lowercases", {
  actual <- cghrCodes:::expandWBDRange("1m01-1M05")
  expected <- c("1m01", "1m02", "1m03", "1m04", "1m05")
  expect_equal(actual, expected)
})

# (expandWBDRange_test_error) Check that ranges with different codex error out
test_that("expandWBDRange() errors out with a suggestion when ranges involve different codex", {
  msg <- "Range .+ must use the same left-hand side codex \\(suggestion: "
  expect_error(cghrCodes:::expandWBDRange("1M01-2M01"), msg)
  expect_error(cghrCodes:::expandWBDRange("1M01-1C01"), msg)
  expect_error(cghrCodes:::expandWBDRange("1M01-3Z01"), msg)
})

# (expandWBDRange_test_singlerange) Check that single codes can be used
test_that("expandWBDRange() handles single codes", {
  actual <- cghrCodes:::expandWBDRange("5D19")
  expected <- "5D19"
  expect_equal(actual, expected)
})

# (expandWBDRange_test_multirange) Check that only 1 range is accepted
test_that("expandWBDRange() errors out for more than one valid range", {
  expect_error(
    cghrCodes:::expandWBDRange("A105-A109-A21"),
    "Invalid range.")
})

# (expandWBDRange_test_symbols) Check that extra symbols are removed
test_that("expandWBDRange() handles extra symbols", {
  actual <- cghrCodes:::expandWBDRange("1M_*!@*01-1M!^0!()*$5")
  expected <- c("1M01", "1M02", "1M03", "1M04", "1M05")
  expect_equal(actual, expected)
})
