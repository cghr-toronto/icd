#' Tests for expandWBD Function
#'
#' Arguments tested: wbd, pattern, removeSpaces
#' \cr
#' Arguments not tested: ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (expandWBD_test_default) Check that example works
test_that("expandWBD() default behaviour works", {
  actual <- cghrCodes::expandWBD(c("1M01-1M03", "1M05", "1B01-03", "1I02-3"))
  expected <- c("1M01", "1M02", "1M03", "1M05", "1B01", "1B02", "1B03", "1I02", "1I03")
  expect_equal(actual, expected)
})

# (expandWBD_test_removeSpaces) Check that codes are accepted even when spaces are not removed
test_that("expandWBD() works without removing spaces", {
  actual <- cghrCodes::expandWBD(c("1P40", "1M39   1M40 "), removeSpaces = FALSE)
  expected <- c("1P40", "1M39", "1M40")
  expect_equal(actual, expected)
})

# (expandWBD_test_pattern) Check that different patterns can be used
test_that("expandWBD() works with different patterns", {
  actual <- cghrCodes::expandWBD("1p40 1p41 11P30", removeSpaces = FALSE, pattern = "[0-9]{1}[a-z]{1}[0-9]+")
  expected <- c("1P40", "1P41")
  expect_equal(actual, expected)
})

# (expandWBD_test_lower) Check that lowercase codes are accepted
test_that("expandWBD() works with lowercase codes", {
  actual <- cghrCodes::expandWBD("1p40 1p41 11P30", removeSpaces = FALSE)
  expected <- c("1P40", "1P41")
  expect_equal(actual, expected)
})

# (expandWBD_test_bad) Check that invalid codes return NULL
test_that("expandWBD() does not expand invalid codes", {
  actual <- cghrCodes::expandWBD("1P302P40")
  expected <- NULL
  expect_equal(actual, expected)
})

# (expandWBD_test_symbols) Check that extra symbols are removed and codes extracted if they exist
test_that("expandWBD() handles extra symbols", {
  actual <- cghrCodes::expandWBD(c("1M(*01-1M()*!03", "1)(*)M05", "1B&**&*01-03", "1I!^!^***02-3"))
  expected <- c("1M01", "1M02", "1M03", "1M05", "1B01", "1B02", "1B03", "1I02", "1I03")
  expect_equal(actual, expected)
})
