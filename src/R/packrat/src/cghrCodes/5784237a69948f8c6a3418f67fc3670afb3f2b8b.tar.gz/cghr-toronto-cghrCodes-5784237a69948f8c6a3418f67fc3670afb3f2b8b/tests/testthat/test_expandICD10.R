#' Tests for expandICD10 Function
#'
#' Arguments tested: icd10, pattern, removeSpaces
#' \cr
#' Arguments not tested: ...
#'
#' @author Nathan Kim <\email{nathan.gyoohyun.kim@gmail.com}>, Richard Wen <\email{rrwen.dev@gmailcom}>
#'

# (expandICD10_test_default) Check that default example works
test_that("expandICD10() default behaviour works", {
  actual <- cghrCodes::expandICD10(c("AA5-AA7", "A4", "A10-A11", "B2", "B3-4", "C25 C28 C29-30"))
  expected <- c("AA05", "AA06", "AA07", "A04", "A10", "A11", "B02", "B03", "B04", "C25", "C28", "C29", "C30")
  expect_equal(actual, expected)
})

# (expandICD10_test_spaces) Check that codes are expanded regardless of spaces
test_that("expandICD10() works without removing spaces", {
  actual <- cghrCodes::expandICD10(c("A20", "A30 B40 "), removeSpaces = FALSE)
  expected <- c("A20", "A30", "B40")
  expect_equal(actual, expected)
})

# (expandICD10_test_pattern) Check that different patterns can be used
test_that("expandICD10() works with different patterns", {
  actual <- cghrCodes::expandICD10("c25 c28", pattern = "[a-z]+[0-9]+")
  expected <- c("C25", "C28")
  expect_equal(actual, expected)
})

# (expandICD10_test_lowercase) Check that lower case codes can be used
test_that("expandICD10() handles lowercase codes", {
  actual <- cghrCodes::expandICD10("c25 c28")
  expected <- c("C25", "C28")
  expect_equal(actual, expected)
})

# (expandICD10_test_symbols) Check that extra symbols do not affect expansion
test_that("expandICD10() handles extra symbols", {
  actual <- cghrCodes::expandICD10(c("AA!@5-AA7*", "A4**", "*A10-**A11", "B#$2", "B3^*&-4", "C25 C28 C29!()-30"))
  expected <- c("AA05", "AA06", "AA07", "A04", "A10", "A11", "B02", "B03", "B04", "C25", "C28", "C29", "C30")
  expect_equal(actual, expected)
})
