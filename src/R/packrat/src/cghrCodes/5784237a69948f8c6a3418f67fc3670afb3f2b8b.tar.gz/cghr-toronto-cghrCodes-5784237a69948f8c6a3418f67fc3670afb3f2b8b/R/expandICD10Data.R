# Requires: expandICD10.R

#' Expand ICD10 Code Ranges in a Dataframe to Single Codes
#'
#' Expands a dataframe with a column of International Classification of Diseases Version 10 (ICD10) ranges to a dataframe with a column containing single ICD10 codes.
#'
#' @param dataframe (dataframe) a \code{\link{data.frame}} containing a column with ICD10 code ranges
#' @param icd10Column (char OR int) [default = ncol(dataframe)] index or name of column containing the ICD10 code ranges
#' @param expandColumn (char) [default = NULL] name of column for single icd10 codes created from expanding the icd10 code ranges (the default of NULL is the icd10 column name with "_expand" added to it)
#' @param ... additional arguments passed to \code{\link{expandICD10}}
#'
#' @return (dataframe) a \code{\link{data.frame}} with the column of ICD10 code ranges expanded to single codes
#' @export
#'
#' @family icd10 functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # Create dataframe with ICD10 code ranges
#' sampleData <- data.frame(codex = c("A", "A1", "C"), icd10 = c("AA5-AA7", "A10-A11", "C25 C28 C29-30"))
#'
#' # Expand the code ranges
#' expanded <- expandICD10Data(sampleData, icd10Column = "icd10")
#'
expandICD10Data <- function(dataframe, icd10Column = ncol(dataframe), expandColumn = NULL, ...) {

  # (expandICD10Dataframe_icd10_column) Get icd10 column index
  if (is.character(icd10Column)) {
    icd10Column <- which(names(dataframe) == icd10Column)
  }

  # (expandICD10Dataframe_split) Split by last column assuming it contains unique sets of icd10 codes
  dataframeSplit <- split(dataframe, dataframe[[icd10Column]])

  # (expandICD10Dataframe_expand) Create expanded dataframe with an added single icd10 codes column
  out <- lapply(dataframeSplit, function(x) {
    rownames(x) <- NULL
    expandedCodes <- expandICD10(x[[icd10Column]], ...)
    expandedDF <- data.frame(x, expandedCodes)
    return(expandedDF)
  })
  out <- do.call("rbind", out)

  # (expandICD10Dataframe_expand_column) Set expanded column name if needed
  if (is.null(expandColumn)) {
    expandColumn <- paste0(names(dataframe)[icd10Column], "_expand")
  }

  # (expandICD10Dataframe_return) Return expanded dataframe
  names(out)[ncol(out)] <- expandColumn
  rownames(out) <- NULL
  return(out)
}
