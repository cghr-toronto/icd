# Requires: removeRegex.R, expandICD10Range.R

#' Expand ICD10 Code Ranges to Single Codes
#'
#' Expands a vector of International Classification of Diseases Version 10 (ICD10) ranges to a vector of single ICD10 codes.
#'
#' @param icd10 (char) vector of single ICD10 codes
#' @param pattern (char) [default = "([a-zA-Z]+[0-9]+\\\\-[a-zA-Z]+[0-9]+)|([a-zA-Z]+[0-9]+\\\\-[0-9]+)|([a-zA-Z]+[0-9]+)"] character value of a regular expression pattern to extract ICD10 codes and ensure they follow a specific format
#' @param removeOther (char) [default = "!#$\%&'()*+,.\\\\/:;<=>?@[\\\\\\^_`\\\\{|\\\\}~"] specific character symbols to remove from each icd10 code
#' @param removeSpaces (bool) [default = TRUE] set to TRUE to remove spaces from each icd10 code and FALSE to keep them
#' @param ... additional arguments passed to \code{\link{expandICD10Range}}
#'
#' @return (char) a vector of characters with single ICD10 codes
#' @export
#'
#' @family icd10 functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # The code below should output
#' # c("AA05", "AA06", "AA07", "A4", "A10", "A11", "B2", "B03", "B04", "C25", "C28", "C29", "C30")
#' expandICD10(c("AA5-AA7", "A4", "A10-A11", "B2", "B3-4", "C25 C28 C29-30"))
#'
expandICD10 <- function(icd10, pattern = "([a-zA-Z]+[0-9]+\\-[a-zA-Z]+[0-9]+)|([a-zA-Z]+[0-9]+\\-[0-9]+)|([a-zA-Z]+[0-9]+)", removeSpaces = TRUE, removeOther =  "!#$%&'()*+,.\\/:;<=>?@[\\\\^_`\\{|\\}~", ...) {

  # (expandICD10_extract) Remove spaces and extract icd10 codes based on pattern
  out <- cghrMisc::removeRegex(icd10, other = removeOther, spaces = removeSpaces)
  out <- unlist(regmatches(out, gregexpr(pattern, out)))

  # (expandICD10_return) Returns the expanded icd10 codes
  out <- unlist(lapply(out, function(x) toupper(expandICD10Range(x, ...))))
  return(out)
}
