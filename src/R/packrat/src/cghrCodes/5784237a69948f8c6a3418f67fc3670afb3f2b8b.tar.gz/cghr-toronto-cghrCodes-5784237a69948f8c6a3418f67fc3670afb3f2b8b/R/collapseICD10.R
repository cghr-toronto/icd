# Requires: expandICD10.R, collapseNumbers.R, keepRegex.R

#' Collapse ICD10 Codes to Ranges
#'
#' Collapses a vector of single International Classification of Diseases Version 10 (ICD10) codes to a vector of ranged ICD10 codes for codes in a consecutive sequence.
#'
#' @inheritParams expandICD10
#' @inheritParams cghrMisc::collapseNumbers
#' @param icd10 (char) vector of single ICD10 codes
#' @param ... additional arguments passed to \code{\link{expandICD10}}
#'
#' @return (char) a vector of characters with ICD10 codes and collapsed ranges
#' @export
#'
#' @family icd10 functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # The code below should output
#' # c("A03-04", "AA05", "B10", "B55-56", "C10", "C100-105")
#' collapseICD10(c("AA5", "A4", "A3", "B55", "B10", "B56", "C10", "C100", "C101", "C102-C105"))
#'
collapseICD10 <- function(icd10, separator = "-", digits = 2, ...) {

  # (collapseICD10_expand) Expand the icd10 codes first and extract the pattern in case there are any ranges or errors
  icd10 <- expandICD10(icd10, digits = digits, ...)

  # (collapseICD10_letter_number) Extract letter and numbers from icd10 codes
  icd10Letters <- cghrMisc::keepRegex(icd10, letters = TRUE)
  icd10Numbers <- as.numeric(cghrMisc::keepRegex(icd10, numbers = TRUE))

  # (collapseICD10_dataframe) Create sorted dataframe of icd10 codes by letter and number
  dataframe <- data.frame(letter = icd10Letters, number = icd10Numbers, stringsAsFactors = FALSE)
  dataframe <- dataframe[with(dataframe, order(letter, number)), ]

  # (collapseICD10_range) Create ranges by letters for icd10 codes assuming they are sorted
  byLetter <- split(dataframe, dataframe$letter)
  out <- lapply(byLetter, function(x) {
    letter <- x$letter[1]
    numberRanges <- cghrMisc::collapseNumbers(x$number, separator, digits = digits)
    collapsed <- paste0(letter, numberRanges)
    return(collapsed)
  })

  # (collapseICD10_return) Return collapsed icd10 codes
  out <- unlist(out, use.names = FALSE)
  return(out)
}
