# Requires: removeRegex.R, expandWBDRange.R

#' Expand WBD Code Ranges to Single Codes
#'
#' Expands a vector of WBD ranges to a vector of single WBD codes.
#'
#' @param wbd (char) vector of single WBD codes
#' @param pattern (char) [default = "\\b(([0-9]{1}[a-zA-z]{1}[0-9]+\\-[0-9]{1}[a-zA-z]{1}[0-9]+)|([0-9]{1}[a-zA-z]{1}[0-9]+\\-[0-9]+)|([0-9]{1}[a-zA-z]{1}[0-9]+))(?=( |$))"] character value of a regular expression pattern to extract WBD codes and ensure they follow a specific format
#' @param removeSpaces (bool) [default = TRUE] set to TRUE to remove spaces from each wbd code and FALSE to keep them
#' @param ... additional arguments passed to \code{\link{expandWBDRange}}
#'
#' @return (char) a vector of characters with single WBD codes
#' @export
#'
#' @family wbd functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # The code below should output
#' # c("1M01", "1M02", "1M03", "1M05", "1B01", "1B02", "1B03", "1I02", "1I03")
#' expandWBD(c("1M01-1M03", "1M05", "1B01-03", "1I02-3"))
#'
expandWBD <- function(wbd, pattern = "\\b(([0-9]{1}[a-zA-z]{1}[0-9]+\\-[0-9]{1}[a-zA-z]{1}[0-9]+)|([0-9]{1}[a-zA-z]{1}[0-9]+\\-[0-9]+)|([0-9]{1}[a-zA-z]{1}[0-9]+))(?=( |$))", removeSpaces = TRUE, ...) {

  # (expandWBD_extract) Remove spaces and extract wbd codes based on pattern
  out <- cghrMisc::removeRegex(wbd, other="!#$%&'()*+,.\\/:;<=>?@[\\\\^_`\\{|\\}~", spaces = removeSpaces)
  out <- unlist(regmatches(out, gregexpr(pattern, out, perl=TRUE)))

  # (expandWBD_return) Returns the expanded wbd codes
  out <- unlist(lapply(out, function(x) toupper(expandWBDRange(x, ...))))
  return(out)
}
