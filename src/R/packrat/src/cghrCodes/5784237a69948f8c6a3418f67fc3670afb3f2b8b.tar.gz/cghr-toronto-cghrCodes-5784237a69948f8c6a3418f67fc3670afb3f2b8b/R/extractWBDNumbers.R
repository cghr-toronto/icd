
#' Extract the Numeric Portion of WBD Codes
#'
#' Internal function for extracting the numeric or right portion of a set of WBD codes.
#' WBD codes are split into left side or codex 2 (2-characters starting with 1 digit and a letter) and right side (2 digits).
#' For example, the WBD code "1E01" contains a left side or codex 2 of "1E" and right side of "01".
#'
#' @param wbd (char) a character vector of WBD codes to extract right or numeric portions from
#'
#' @return (char) returns a character vector of the numeric portions of WBD codes
#' @keywords internal
#'
#' @family internal wbd functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # "01" "02" "05" "03"
#' cghrCodes:::extractWBDNumbers(c("1M01", "1M02", "1B05", "1I03"))
#'
extractWBDNumbers <- function(wbd) {

  # (extractWBDNumbers_apply) Apply extraction function to vector of WBD codes
  out <- sapply(wbd, function(x) {

    # (extractWBDNumbers_full) Assume 1st digit is part of left side if full code
    if (nchar(x) > 2) {
      x <- substr(x, 2, nchar(x))
    }

    # (extractWBDNumbers_numeric) Numeric values only
    x <- gsub("[^0-9]", "", x)
    return(x)
  })

  # (extractWBDNumbers_return) Return numeric portions of WBD codes
  return(unname(out))
}
