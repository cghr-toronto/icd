
#' Extract the Left Portion of WBD Codes
#'
#' Internal function for extracting the left portion (codex 2) of a set of WBD codes.
#' WBD codes are split into left side or codex 2 (2-characters starting with 1 digit and a letter) and right side (2 digits).
#' For example, the WBD code "1E01" contains a left side or codex 2 of "1E" and right side of "01".
#'
#' @param wbd (char) a character vector of WBD codes to extract left portions from
#' @param leftPattern (char) [default = "[0-9]{1}[A-Z]{1}"] a character value of the regex pattern used to extract the left portion of WBD codes
#'
#' @return (char) returns a character vector of the left portions of WBD codes
#' @keywords internal
#'
#' @family internal wbd functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # "1M" "1M" "1B" "1I"
#' cghrCodes:::extractWBDLeft(c("1M01", "1M02", "1B05", "1I03"))
#'
extractWBDLeft <- function(wbd, leftPattern = "[0-9]{1}[a-zA-Z]{1}") {
  out <- unlist(regmatches(wbd, gregexpr(leftPattern, wbd)))
  return(out)
}
