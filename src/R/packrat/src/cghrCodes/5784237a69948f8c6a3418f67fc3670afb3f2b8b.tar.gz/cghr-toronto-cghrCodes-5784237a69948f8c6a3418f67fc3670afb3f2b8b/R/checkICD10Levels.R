# Requires: expandICD10.R

#' Check If Lower Level ICD10 10 Codes are in Higher Level ICD10 10 Codes
#'
#' Adds a column that shows the missing lower level ICD10 10 codes that should be in the higher level ICD10 10 codes
#'
#' @param dataframe (dataframe)
#' @param higherICD10Column (int OR char) [default = 1] column with higher level ICD10 10 codes
#' @param lowerICD10Column (int OR char) [default = 2] column with lower level ICD10 10 codes
#' @param checkColumn (char) [default = NULL] name of the column for missing lower level icd10 codes that should be in higher level icd10 codes separated by spaces (the default of NULL is the lower level icd10 column name and higher level icd10 column name with "_missed_in_" added between them)
#' @param ... additional arguments passed to \code{\link{expandICD10}}
#'
#' @return (dataframe) a \code{\link{data.frame}} with the an extra column showing the missing lower level ICD10 codes that should be in the higher level ICD10 codes
#' @export
#'
#' @family icd10 functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # Create dataframe with ICD10 code ranges
#' sampleData <- data.frame(icd10_high = c("AA5-AA10", "AA5-AA10", "C1-5"), icd10_low = c("AA5-AA7", "AA1-AA9", "C1 C2 C12"))
#'
#' # Check if icd10_low is in icd10_high
#' checkData <- checkICD10Levels(sampleData)
#'
checkICD10Levels <- function(dataframe, higherICD10Column = 1, lowerICD10Column = 2, checkColumn = NULL, ...) {

  # (checkICD10Levels_columns) Get icd10 column indices
  if (is.character(higherICD10Column)) {
    higherICD10Column <- which(names(dataframe) == higherICD10Column)
  }
  if (is.character(lowerICD10Column)) {
    lowerICD10Column <- which(names(dataframe) == lowerICD10Column)
  }

  # (checkICD10Levels_missing) Find missing ICD10s
  missing <- apply(dataframe, 1, function(x) {

    # (checkICD10Levels_missing_levels) Get higher and lower level expanded icd10 codes
    higherICD10s <- expandICD10(x[[higherICD10Column]], ...)
    lowerICD10s <- expandICD10(x[[lowerICD10Column]], ...)

    # (checkICD10Levels_missing_find) Find missing icd10s by checking if lower level codes are in higher level codes
    missingInHigher <- !(lowerICD10s %in% higherICD10s)
    missingLowerICD10s <- paste(lowerICD10s[missingInHigher], collapse = " ")
    return(missingLowerICD10s)
  })
  missing <- unlist(missing)

  # (checkICD10Levels_column) Automatically name the added column if NULL is given
  if (is.null(checkColumn)) {
    checkColumn <- paste0(names(dataframe)[lowerICD10Column], "_missed_in_", names(dataframe)[higherICD10Column])
  }

  # (checkICD10Levels_return) Return a column showing the missing icd10 codes according to the chosen levels
  out <- dataframe
  out[[checkColumn]] <- missing
  return(out)
}
