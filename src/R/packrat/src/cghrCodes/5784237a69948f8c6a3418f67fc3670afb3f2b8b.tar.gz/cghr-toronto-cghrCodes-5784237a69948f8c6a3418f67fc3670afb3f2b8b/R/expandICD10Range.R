
#' Expand an ICD10 Range into Single ICD10 Codes
#'
#' Internal function for expanding an International Classification of Diseases Version 10 (ICD10) code range into single ICD10 codes.
#'
#' @param icd10Range (char) a character value containing an ICD10 code range with the same letter
#' @param digits (int) [default = 2] an integer value indicating the minimum number of digits for number codes (e.g. if digits is 2, 1 will be 01, and 0 will be 00)
#'
#' @return (char) returns a character vector of single ICD10 codes expanded from the ICD10 range or errors out if the letter codes in the range are not the same
#' @keywords internal
#'
#' @family internal icd10 functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # "A01" "A02" "A03" "A04" "A05"
#' cghrCodes:::expandICD10Range("A1-5")
#'
expandICD10Range <- function(icd10Range, digits = 2) {

  # (expandICD10Range_conditions) Conditions for checks
  separator <- "-"
  separatorCount <- nchar(cghrMisc::keepRegex(icd10Range, other = separator))
  hasValidSeparator <-  separatorCount == 1
  isSingleCode <- grepl("^[a-zA-Z]+[0-9]+", icd10Range) && separatorCount < 1

  # (expandICD10Range_check_range) Valid range if only 1 dash
  if (hasValidSeparator) {

    # (expandICD10Range_split) Split into lower and higher ranges
    splitRange <- strsplit(icd10Range, separator)[[1]]

    # (expandICD10Range_number) Extract numeric portion of the icd10 codes
    numberRange <- gsub("[^0-9]", "", splitRange)

    # (expandICD10Range_letter) Extract the letter portion of the icd10 codes
    letterRange <- gsub("[^a-zA-Z]", "", splitRange)
    if (length(unique(tolower(letterRange))) != 1 && !("" %in% letterRange)) {
      stop(paste0("Range ", icd10Range, " must use the same letter (suggestion: ", letterRange[1], numberRange[1], separator, "99, ", letterRange[2], "00", separator, numberRange[2], ")."))
    }
    letter <- letterRange[1] # Use first extracted letter

    # (expandICD10Range_expand) Expand the numeric range and add the letter to each expanded number
    out <- sprintf(paste0(letter,"%0", digits, "d"), seq(numberRange[1], numberRange[2]))

  } else if (isSingleCode) {

    # (expandICD10Range_check_single) Single code if no separators and only alphanumerics
    letter <- gsub("[^a-zA-Z]", "", icd10Range)
    number <- as.numeric(gsub("[^0-9]", "", icd10Range))
    out <- sprintf(paste0(letter,"%0", digits, "d"), number)

  } else {

    # (expandICD10Range_error) Error if more than one dash or not a single code
    stop("Invalid range.")
  }
  return(out)
}
