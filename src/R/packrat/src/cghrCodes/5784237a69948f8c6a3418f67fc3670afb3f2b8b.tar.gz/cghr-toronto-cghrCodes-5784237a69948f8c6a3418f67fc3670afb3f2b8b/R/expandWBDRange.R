# Requires: extractWBDNumbers.R, extractWBDLeft.R

#' Expand a WBD Range into Single WBD Codes
#'
#' Internal function for expanding a WBD code range into single WBD codes.
#' WBD codes are split into left side or codex 2 (2-characters starting with 1 digit and a letter) and right side (2 digits).
#' For example, the WBD code "1E01" contains a left side or codex 2 of "1E" and right side of "01".
#'
#' @inheritParams extractWBDLeft
#' @param wbdRange (char) a character value containing a WBD code range with the same left side portion
#' @param digits (int) [default = 2] an integer value indicating the minimum number of digits for right side number codes (e.g. if digits is 2, 1 will be 01, and 0 will be 00)
#' @param ... additional arguments passed to \code{\link{extractWBDLeft}}
#'
#' @return (char) returns a character vector of single WBD codes expanded from the WBD range or errors out if the left side codes in the range are not the same
#' @keywords internal
#'
#' @family internal wbd functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # "1M01" "1M02" "1M03" "1M04" "1M05"
#' cghrCodes:::expandWBDRange("1M01-1M05")
#'
expandWBDRange <- function(wbdRange, digits = 2, ...) {

  # (expandWBDRange_remove) Remove unwanted characters
  wbdRange <- cghrMisc::removeRegex(wbdRange, other = "!#$%&'()*+,.\\/:;<=>?@[\\\\^_`\\{|\\}~", spaces = TRUE)

  # (expandICDRange_conditions) Conditions for checks
  separator <- "-"
  separatorCount <- nchar(cghrMisc::keepRegex(wbdRange, other = separator))
  hasValidSeparator <- separatorCount == 1
  isSingleCode <- grepl("^[0-9]+[a-zA-Z]+", wbdRange) && separatorCount < 1

  # (expandWBDRange_check) Valid range if only 1 dash
  if (hasValidSeparator) {

    # (expandWBDRange_split) Split into lower and higher ranges
    splitRange <- strsplit(wbdRange, "-")[[1]]

    # (expandWBDRange_number) Extract numeric portion of the wbd codes
    numberRange <- extractWBDNumbers(splitRange)

    # (expandWBDRange_left) Extract the left side portion of the wbd codes
    leftRange <- extractWBDLeft(splitRange, ...)
    if (length(unique(tolower(leftRange))) != 1 && !("" %in% leftRange)) {
      stop(paste0("Range ", wbdRange, " must use the same left-hand side codex (suggestion: ", leftRange[1], numberRange[1], "-09, ", leftRange[2], "00-", numberRange[2], ")."))
    }
    left <- leftRange[1] # Use first extracted left portion code

    # (expandWBDRange_expand) Expand the numeric range and add the left portion to each expanded number
    out <- sprintf(paste0(left, "%0", digits, "d"), seq(numberRange[1], numberRange[2]))

  } else if (isSingleCode) {

    # (expandWBDRange_check_single) Single code if no separators and only alphanumerics
    codex2 <- extractWBDLeft(wbdRange) # left-hand side codex 2 assume first 2 characters
    number <- as.numeric(extractWBDNumbers(wbdRange)) # right-hand side assume to be after first 2 characters
    out <- sprintf(paste0(codex2, "%0", digits, "d"), number)

  } else {

    # (expandWBDRange_error) Error if more than one dash or not a single code
    stop("Invalid range.")
  }
  return(out)
}
