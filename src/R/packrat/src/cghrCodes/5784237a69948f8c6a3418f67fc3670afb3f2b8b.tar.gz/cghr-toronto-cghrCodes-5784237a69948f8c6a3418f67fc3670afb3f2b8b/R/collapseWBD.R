# Requires: expandWBD.R, expandWBDRange.R, extractWBDLeft.R, collapseNumbers.R

#' Collapse WBD Codes to Ranges
#'
#' Collapses a vector of single WBD codes to a vector of ranged WBD codes for codes in a consecutive sequence.
#'
#' @inheritParams expandWBD
#' @inheritParams expandWBDRange
#' @inheritParams extractWBDLeft
#' @inheritParams cghrMisc::collapseNumbers
#' @param wbd (char) vector of single WBD codes
#' @param ... additional arguments passed to \code{\link{expandWBD}}
#'
#' @return (char) a vector of characters with WBD codes and collapsed ranges
#' @export
#'
#' @family wbd functions
#' @author Richard Wen <\email{rrwen.dev@gmailcom}>
#'
#' @examples
#' library(cghrCodes)
#'
#' # The code below should output
#' # c("1B01", "1I01-04", "1M03-05")
#' collapseWBD(c("1M05", "1M04", "1M03", "1B01", "1I01-1I03", "1I04"))
#'
collapseWBD <- function(wbd, separator = "-", digits = 2, leftPattern = "[0-9]{1}[A-Z]{1}", ...) {

  # (collapseWBD_expand) Expand the wbd codes first and extract the pattern in case there are any ranges or errors
  wbd <- expandWBD(wbd, digits = digits, ...)

  # (collapseWBD_left_number) Extract left portion and numbers from wbd codes
  wbdLeft <- extractWBDLeft(wbd, leftPattern)
  wbdNumbers <- as.numeric(extractWBDNumbers(wbd))

  # (collapseWBD_dataframe) Create sorted dataframe of wbd codes by left portion and number
  dataframe <- data.frame(left = wbdLeft, number = wbdNumbers, stringsAsFactors = FALSE)
  dataframe <- dataframe[with(dataframe, order(left, number)), ]

  # (collapseWBD_range) Create ranges by left portions for wbd codes assuming they are sorted
  byLeft <- split(dataframe, dataframe$left)
  out <- lapply(byLeft, function(x) {
    left <- x$left[1]
    numberRanges <- cghrMisc::collapseNumbers(x$number, separator, digits = digits)
    collapsed <- paste0(left, numberRanges)
    return(collapsed)
  })

  # (collapseWBD_return) Return collapsed wbd codes
  out <- unlist(out, use.names = FALSE)
  return(out)
}
