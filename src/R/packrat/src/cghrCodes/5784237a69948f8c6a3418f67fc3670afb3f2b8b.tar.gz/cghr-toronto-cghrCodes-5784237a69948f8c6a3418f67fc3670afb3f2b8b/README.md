# cghrCodes

Richard Wen <rrwen.dev@gmail.com>  

R package with tools for working with death and disease codes used at CGHR 

## Features

* Fault-tolerant [International Classification of Diseases Version 10 (ICD10)](https://icd.who.int/browse10/2016/en) and reclassified [CGHR Wilson's Burden of Disease (WBD)](https://static-content.springer.com/esm/art%3A10.1186%2F1741-7015-12-21/MediaObjects/12916_2013_909_MOESM3_ESM.pdf) code parsing that accounts for human error
* Automatic expanding and collapsing of ICD10 and WBD codes and ranges
* Convenient checks for ICD10 code hierarchy inconsistencies

## Acknowledgements

Thanks to Nathan Kim from University of Toronto Schools (UTS) for his help with writing unit tests for this package during his Summer 2019 internship.

## Install

1. Install [R](https://www.r-project.org/) and [RTools](https://cran.r-project.org/bin/windows/Rtools/)
2. Install the [RStudio](https://www.rstudio.com/products/rstudio/download/#download) code editor
3. Open an [R Console](https://support.rstudio.com/hc/en-us/articles/200404846-Working-in-the-Console) in RStudio
4. Install [devtools](https://cran.r-project.org/package=devtools)
5. Install the `cghrCodes` package with `install_github`

```R
install.packages("devtools")
Sys.setenv(GITHUB_PAT = "<TOKEN>")
devtools::install_github("cghr-toronto/cghrCodes")
```

**Note:** Replace `<Token>` inside the quotations `"` with the current access token available [here](https://github.com/cghr-toronto/start-here#repository-access-token)

## Usage

Use in an R Console:

```R
library(cghrCodes)

# Create dataframe with ICD code ranges
codes <- data.frame(
  wbd = c("1A01", "2T01", "1M03"),
  icd10 = c("AA5-AA7", "A10-A11", "C25 C28 C29-30"))

# Expand the code ranges as a dataframe
exICD10Data <- expandICD10Data(codes, icdColumn = "icd10")

# Expand the icd10 column codes and ranges as a vector
exICD10 <- expandICD10(codes$icd10)

# Collapse the icd10 column codes and ranges as vector
coICD10 <- collapseICD10(codes$icd10)

# Collapse the wbd column codes and ranges as a vector
exWBD <- expandWBD(codes$wbd)

# Expand the wbd column codes and ranges as a vector
coWBD <- collapseWBD(codes$wbd)
```
